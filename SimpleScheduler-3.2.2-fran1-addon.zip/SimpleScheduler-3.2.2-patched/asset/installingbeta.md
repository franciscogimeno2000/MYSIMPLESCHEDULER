# Install the beta version

*First of all, thank you for helping me test the beta!*

Add the beta repository

https://github.com/arthurdent75/SimpleScheduler-BETA

or click on the link below:

[<img src="https://my.home-assistant.io/badges/supervisor_add_addon_repository.svg">](https://my.home-assistant.io/redirect/supervisor_add_addon_repository/?repository_url=https%3A%2F%2Fgithub.com%2Farthurdent75%2FSimpleScheduler-BETA) 

You don't need to remove the official repository

![image](https://github.com/user-attachments/assets/4911b40d-886b-4b29-a74c-3ed7eafce675)

After that, uninstall the **Simple Scheduler** addon...

![image](https://github.com/user-attachments/assets/149e26d4-09b0-4e48-a214-b316bf3e9e81)

...and install the **Simple Scheduler (beta)** addon

![image](https://github.com/user-attachments/assets/be55d5ad-71b3-4463-bd74-00c7dad42197)

All the settings and the schedulers will be kept, but please **execute a backup for safety**.
